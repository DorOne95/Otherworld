
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.otherworld.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.otherworld.item.SoulItem;
import net.mcreator.otherworld.item.OtherWorldItem;
import net.mcreator.otherworld.item.OtherWorldFragmentItem;
import net.mcreator.otherworld.item.OtherWorldEmptyFragmentItem;
import net.mcreator.otherworld.item.NeonItem;
import net.mcreator.otherworld.item.GrimSwordItem;
import net.mcreator.otherworld.item.GrimShovelItem;
import net.mcreator.otherworld.item.GrimPickaxeItem;
import net.mcreator.otherworld.item.GrimHoeItem;
import net.mcreator.otherworld.item.GrimAxeItem;
import net.mcreator.otherworld.item.Bloob_woodSwordItem;
import net.mcreator.otherworld.item.Bloob_woodShovelItem;
import net.mcreator.otherworld.item.Bloob_woodPickaxeItem;
import net.mcreator.otherworld.item.Bloob_woodHoeItem;
import net.mcreator.otherworld.item.Bloob_woodAxeItem;
import net.mcreator.otherworld.OtherWorldMod;

public class OtherWorldModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OtherWorldMod.MODID);
	public static final RegistryObject<Item> PORTAL_BLOCK = block(OtherWorldModBlocks.PORTAL_BLOCK);
	public static final RegistryObject<Item> PORTAL_BLOCKON = block(OtherWorldModBlocks.PORTAL_BLOCKON);
	public static final RegistryObject<Item> OTHER_WORLD_FRAGMENT = REGISTRY.register("other_world_fragment", () -> new OtherWorldFragmentItem());
	public static final RegistryObject<Item> SOUL = REGISTRY.register("soul", () -> new SoulItem());
	public static final RegistryObject<Item> OTHER_WORLD = REGISTRY.register("other_world", () -> new OtherWorldItem());
	public static final RegistryObject<Item> OTHER_WORLD_EMPTY_FRAGMENT = REGISTRY.register("other_world_empty_fragment", () -> new OtherWorldEmptyFragmentItem());
	public static final RegistryObject<Item> SLIMY_GRASS = block(OtherWorldModBlocks.SLIMY_GRASS);
	public static final RegistryObject<Item> DIRT = block(OtherWorldModBlocks.DIRT);
	public static final RegistryObject<Item> GRIM_STONE = block(OtherWorldModBlocks.GRIM_STONE);
	public static final RegistryObject<Item> GRIM_COBBLESTONE = block(OtherWorldModBlocks.GRIM_COBBLESTONE);
	public static final RegistryObject<Item> GRIM_PICKAXE = REGISTRY.register("grim_pickaxe", () -> new GrimPickaxeItem());
	public static final RegistryObject<Item> GRIM_AXE = REGISTRY.register("grim_axe", () -> new GrimAxeItem());
	public static final RegistryObject<Item> GRIM_SWORD = REGISTRY.register("grim_sword", () -> new GrimSwordItem());
	public static final RegistryObject<Item> GRIM_SHOVEL = REGISTRY.register("grim_shovel", () -> new GrimShovelItem());
	public static final RegistryObject<Item> GRIM_HOE = REGISTRY.register("grim_hoe", () -> new GrimHoeItem());
	public static final RegistryObject<Item> NEON_BUCKET = REGISTRY.register("neon_bucket", () -> new NeonItem());
	public static final RegistryObject<Item> BLOOB_LOG = block(OtherWorldModBlocks.BLOOB_LOG);
	public static final RegistryObject<Item> BLOOB_PLANKS = block(OtherWorldModBlocks.BLOOB_PLANKS);
	public static final RegistryObject<Item> BLOOB_STAIRS = block(OtherWorldModBlocks.BLOOB_STAIRS);
	public static final RegistryObject<Item> BLOOB_SLAB = block(OtherWorldModBlocks.BLOOB_SLAB);
	public static final RegistryObject<Item> BLOOB_FENCE = block(OtherWorldModBlocks.BLOOB_FENCE);
	public static final RegistryObject<Item> BLOOB_FENCE_GATE = block(OtherWorldModBlocks.BLOOB_FENCE_GATE);
	public static final RegistryObject<Item> BLOOB_PRESSURE_PLATE = block(OtherWorldModBlocks.BLOOB_PRESSURE_PLATE);
	public static final RegistryObject<Item> BLOOB_BUTTON = block(OtherWorldModBlocks.BLOOB_BUTTON);
	public static final RegistryObject<Item> BLOOB_WOOD_PICKAXE = REGISTRY.register("bloob_wood_pickaxe", () -> new Bloob_woodPickaxeItem());
	public static final RegistryObject<Item> BLOOB_WOOD_AXE = REGISTRY.register("bloob_wood_axe", () -> new Bloob_woodAxeItem());
	public static final RegistryObject<Item> BLOOB_WOOD_SWORD = REGISTRY.register("bloob_wood_sword", () -> new Bloob_woodSwordItem());
	public static final RegistryObject<Item> BLOOB_WOOD_SHOVEL = REGISTRY.register("bloob_wood_shovel", () -> new Bloob_woodShovelItem());
	public static final RegistryObject<Item> BLOOB_WOOD_HOE = REGISTRY.register("bloob_wood_hoe", () -> new Bloob_woodHoeItem());
	public static final RegistryObject<Item> BLOOB_LEAVES = block(OtherWorldModBlocks.BLOOB_LEAVES);
	public static final RegistryObject<Item> GRASS = block(OtherWorldModBlocks.GRASS);
	public static final RegistryObject<Item> BUSH = doubleBlock(OtherWorldModBlocks.BUSH);
	public static final RegistryObject<Item> BURNED_GRASS = block(OtherWorldModBlocks.BURNED_GRASS);
	public static final RegistryObject<Item> ASHSES = block(OtherWorldModBlocks.ASHSES);
	public static final RegistryObject<Item> DEAD_GRASS = block(OtherWorldModBlocks.DEAD_GRASS);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}
