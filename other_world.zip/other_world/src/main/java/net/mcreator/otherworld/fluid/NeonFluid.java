
package net.mcreator.otherworld.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.otherworld.init.OtherWorldModItems;
import net.mcreator.otherworld.init.OtherWorldModFluids;
import net.mcreator.otherworld.init.OtherWorldModFluidTypes;
import net.mcreator.otherworld.init.OtherWorldModBlocks;

public abstract class NeonFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> OtherWorldModFluidTypes.NEON_TYPE.get(), () -> OtherWorldModFluids.NEON.get(), () -> OtherWorldModFluids.FLOWING_NEON.get())
			.explosionResistance(100f).tickRate(2).slopeFindDistance(10).bucket(() -> OtherWorldModItems.NEON_BUCKET.get()).block(() -> (LiquidBlock) OtherWorldModBlocks.NEON.get());

	private NeonFluid() {
		super(PROPERTIES);
	}

	public static class Source extends NeonFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends NeonFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
