
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.otherworld.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.otherworld.OtherWorldMod;

public class OtherWorldModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, OtherWorldMod.MODID);
	public static final RegistryObject<SimpleParticleType> PORTAL_PARTICLE = REGISTRY.register("portal_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> AMBIENT_1 = REGISTRY.register("ambient_1", () -> new SimpleParticleType(false));
}
