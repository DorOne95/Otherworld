
package net.mcreator.otherworld.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.otherworld.init.OtherWorldModFluids;

public class NeonItem extends BucketItem {
	public NeonItem() {
		super(OtherWorldModFluids.NEON, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
