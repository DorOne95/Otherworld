
package net.mcreator.otherworld.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.otherworld.client.particle.PortalParticleParticle;
import net.mcreator.otherworld.client.particle.Ambient1Particle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class OtherWorldModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(OtherWorldModParticleTypes.PORTAL_PARTICLE.get(), PortalParticleParticle::provider);
		event.registerSpriteSet(OtherWorldModParticleTypes.AMBIENT_1.get(), Ambient1Particle::provider);
	}
}
