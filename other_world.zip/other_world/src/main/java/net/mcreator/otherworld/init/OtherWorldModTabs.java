
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.otherworld.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.otherworld.OtherWorldMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OtherWorldModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OtherWorldMod.MODID);
	public static final RegistryObject<CreativeModeTab> OTHER_WORLD_BLOCKS = REGISTRY.register("other_world_blocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.other_world.other_world_blocks")).icon(() -> new ItemStack(OtherWorldModBlocks.PORTAL_BLOCKON.get())).displayItems((parameters, tabData) -> {
				tabData.accept(OtherWorldModBlocks.PORTAL_BLOCK.get().asItem());
				tabData.accept(OtherWorldModBlocks.SLIMY_GRASS.get().asItem());
				tabData.accept(OtherWorldModBlocks.DIRT.get().asItem());
				tabData.accept(OtherWorldModBlocks.GRIM_STONE.get().asItem());
				tabData.accept(OtherWorldModBlocks.GRIM_COBBLESTONE.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_LOG.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_PLANKS.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_STAIRS.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_SLAB.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_FENCE.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_FENCE_GATE.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_PRESSURE_PLATE.get().asItem());
				tabData.accept(OtherWorldModBlocks.BLOOB_BUTTON.get().asItem());
				tabData.accept(OtherWorldModBlocks.GRASS.get().asItem());
				tabData.accept(OtherWorldModBlocks.BURNED_GRASS.get().asItem());
				tabData.accept(OtherWorldModBlocks.DEAD_GRASS.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> OTHER_WORLD_ITEMS = REGISTRY.register("other_world_items",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.other_world.other_world_items")).icon(() -> new ItemStack(OtherWorldModItems.OTHER_WORLD_FRAGMENT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(OtherWorldModItems.OTHER_WORLD_FRAGMENT.get());
				tabData.accept(OtherWorldModItems.OTHER_WORLD.get());
				tabData.accept(OtherWorldModItems.SOUL.get());
				tabData.accept(OtherWorldModItems.OTHER_WORLD_EMPTY_FRAGMENT.get());
				tabData.accept(OtherWorldModItems.GRIM_PICKAXE.get());
				tabData.accept(OtherWorldModItems.GRIM_AXE.get());
				tabData.accept(OtherWorldModItems.GRIM_SWORD.get());
				tabData.accept(OtherWorldModItems.GRIM_SHOVEL.get());
				tabData.accept(OtherWorldModItems.GRIM_HOE.get());
				tabData.accept(OtherWorldModItems.NEON_BUCKET.get());
				tabData.accept(OtherWorldModItems.BLOOB_WOOD_PICKAXE.get());
				tabData.accept(OtherWorldModItems.BLOOB_WOOD_AXE.get());
				tabData.accept(OtherWorldModItems.BLOOB_WOOD_SWORD.get());
				tabData.accept(OtherWorldModItems.BLOOB_WOOD_SHOVEL.get());
				tabData.accept(OtherWorldModItems.BLOOB_WOOD_HOE.get());
				tabData.accept(OtherWorldModBlocks.BLOOB_LEAVES.get().asItem());
				tabData.accept(OtherWorldModBlocks.ASHSES.get().asItem());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(OtherWorldModBlocks.BUSH.get().asItem());
		}
	}
}
