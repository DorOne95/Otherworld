
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.otherworld.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.otherworld.block.SlimyGrassBlock;
import net.mcreator.otherworld.block.PortalBlockonBlock;
import net.mcreator.otherworld.block.PortalBlockBlock;
import net.mcreator.otherworld.block.OtherWorldPortalBlock;
import net.mcreator.otherworld.block.NeonBlock;
import net.mcreator.otherworld.block.GrimStoneBlock;
import net.mcreator.otherworld.block.GrimCobblestoneBlock;
import net.mcreator.otherworld.block.GrassBlock;
import net.mcreator.otherworld.block.DirtBlock;
import net.mcreator.otherworld.block.DeadGrassBlock;
import net.mcreator.otherworld.block.BushBlock;
import net.mcreator.otherworld.block.BurnedGrassBlock;
import net.mcreator.otherworld.block.BloobStairsBlock;
import net.mcreator.otherworld.block.BloobSlabBlock;
import net.mcreator.otherworld.block.BloobPressurePlateBlock;
import net.mcreator.otherworld.block.BloobPlanksBlock;
import net.mcreator.otherworld.block.BloobLogBlock;
import net.mcreator.otherworld.block.BloobLeavesBlock;
import net.mcreator.otherworld.block.BloobFenceGateBlock;
import net.mcreator.otherworld.block.BloobFenceBlock;
import net.mcreator.otherworld.block.BloobButtonBlock;
import net.mcreator.otherworld.block.AshsesBlock;
import net.mcreator.otherworld.OtherWorldMod;

public class OtherWorldModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OtherWorldMod.MODID);
	public static final RegistryObject<Block> PORTAL_BLOCK = REGISTRY.register("portal_block", () -> new PortalBlockBlock());
	public static final RegistryObject<Block> PORTAL_BLOCKON = REGISTRY.register("portal_blockon", () -> new PortalBlockonBlock());
	public static final RegistryObject<Block> OTHER_WORLD_PORTAL = REGISTRY.register("other_world_portal", () -> new OtherWorldPortalBlock());
	public static final RegistryObject<Block> SLIMY_GRASS = REGISTRY.register("slimy_grass", () -> new SlimyGrassBlock());
	public static final RegistryObject<Block> DIRT = REGISTRY.register("dirt", () -> new DirtBlock());
	public static final RegistryObject<Block> GRIM_STONE = REGISTRY.register("grim_stone", () -> new GrimStoneBlock());
	public static final RegistryObject<Block> GRIM_COBBLESTONE = REGISTRY.register("grim_cobblestone", () -> new GrimCobblestoneBlock());
	public static final RegistryObject<Block> NEON = REGISTRY.register("neon", () -> new NeonBlock());
	public static final RegistryObject<Block> BLOOB_LOG = REGISTRY.register("bloob_log", () -> new BloobLogBlock());
	public static final RegistryObject<Block> BLOOB_PLANKS = REGISTRY.register("bloob_planks", () -> new BloobPlanksBlock());
	public static final RegistryObject<Block> BLOOB_STAIRS = REGISTRY.register("bloob_stairs", () -> new BloobStairsBlock());
	public static final RegistryObject<Block> BLOOB_SLAB = REGISTRY.register("bloob_slab", () -> new BloobSlabBlock());
	public static final RegistryObject<Block> BLOOB_FENCE = REGISTRY.register("bloob_fence", () -> new BloobFenceBlock());
	public static final RegistryObject<Block> BLOOB_FENCE_GATE = REGISTRY.register("bloob_fence_gate", () -> new BloobFenceGateBlock());
	public static final RegistryObject<Block> BLOOB_PRESSURE_PLATE = REGISTRY.register("bloob_pressure_plate", () -> new BloobPressurePlateBlock());
	public static final RegistryObject<Block> BLOOB_BUTTON = REGISTRY.register("bloob_button", () -> new BloobButtonBlock());
	public static final RegistryObject<Block> BLOOB_LEAVES = REGISTRY.register("bloob_leaves", () -> new BloobLeavesBlock());
	public static final RegistryObject<Block> GRASS = REGISTRY.register("grass", () -> new GrassBlock());
	public static final RegistryObject<Block> BUSH = REGISTRY.register("bush", () -> new BushBlock());
	public static final RegistryObject<Block> BURNED_GRASS = REGISTRY.register("burned_grass", () -> new BurnedGrassBlock());
	public static final RegistryObject<Block> ASHSES = REGISTRY.register("ashses", () -> new AshsesBlock());
	public static final RegistryObject<Block> DEAD_GRASS = REGISTRY.register("dead_grass", () -> new DeadGrassBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
